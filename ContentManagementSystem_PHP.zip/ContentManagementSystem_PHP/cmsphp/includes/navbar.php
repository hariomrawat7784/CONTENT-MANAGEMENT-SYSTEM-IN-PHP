<div id="navbar">
<ul id="ul">
	<li><a href="index.php">Home</a></li>
	<li><a href="downloads.php">Downloads</a></li>
	<li><a href="aboutus.php">About-us</a></li>
	<li><a href="contact.php">Contact</a></li>
</ul>
	
<div id="searchbox">

	
<center>	
	<form action="search.php" method="get" enctype="multipart/form-data">
	<ul>
	<input type="text" name="value" placeholder=" search topic" size="25">
	
	<input type="submit" name="search" value="Search"> 
	
	
	
	</ul>


	</form>
</center>

</div>
	

</div>