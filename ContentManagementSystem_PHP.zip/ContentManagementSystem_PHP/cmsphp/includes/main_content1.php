<div id="main_content1">

<h1>Below are the pdf files for download</h1>
<center><table bgcolor="olive" colspan="20" border="3" width="60%" height="80">

<tr>
	<td><b><h4>Introduction to Autodesk 3dsmax</h4></b></td>
	<td><a href="downloads/Introduction_to_Autodesk_3dsmax.pdf"><center>Download<center></td>
</tr>

<tr>
	<td><b><h4>Getting used to your tools</h4></b></td>
	<td><a href="downloads/Getting_used_to_your_tools.pdf"><center>Download</center></td>
</tr>

<tr>
	<td><b><h4>Understanding your working Layout</h4></b></td>
	<td><a href="downloads/Understanding_your_working_layout.pdf"><center>Download</center></td>
</tr>

<tr>
	<td><b><h4>Object editing</h4></b></td>
	<td><a href="downloads/Object_editing.pdf"><center>Download</center></td>
</tr>

<tr>
	<td><b><h4>Using Light</h4></b></td>
	<td><a href="downloads/Using_Light.pdf"><center>Download</center></td>
</tr>

<tr>
	<td><b><h4>Applying material</h4></b></td>
	<td><a href="downloads/Applying_material.pdf"><center>Download</center></td>
</tr>

<tr>
	<td><b><h4>Animation</h4></b></td>
	<td><a href="downloads/Animation.pdf"><center>Download</center></td>
</tr>

<tr>
	<td><b><h4>Saving your work</h4></b></td>
	<td><a href="downloads/Saving_your_work.pdf"><center>Download</center></td>
</tr>


</table>
</center>
</div>
